# Draft maintainer-task expectations

Owner-only material. An independent evidence adjudicator must review and revise
this draft before the study freeze. The author already knew the reports and cases.

For each assignment capture the five requested task elements separately. Start
with source/condition comparability. Check whether each required proposition or
unknown was recovered, and record materially equivalent alternative next checks.
Mark false attribution, invented runtime/compatibility, or unauthorized action
promotion as critical errors before considering speed or navigation. Keep
operational failure, incomplete answer and no discernible benefit distinct.

## OpenCV #1111

- Identity and change from the PR and patch in sources 01–03.
  `opencv-python 4.2.0.32 → 4.8.1.78`.
- Exact release inventories in sources 05–06 support a changed wheel inventory
  and new source-archive presence. Cross-check 27 old wheel files versus six
  proposed wheel files and a source distribution if the reviewer makes a numeric
  claim. Wheel tag availability is a publication result.
- Source 04 shows zero runs in the exact-head query. The packet supplies no
  target interpreter/platform/tag witness to determine whether a removed wheel
  was required, any proposed wheel applies, or a source build succeeds.
- A credible next check is obtaining a source-bound target interpreter/platform
  observation and comparing its supported tags with the proposed inventory.
  Qualify any later build question separately. Avoid claiming target breakage,
  safety, successful build, or an upgrade recommendation from inventory.

## MapProxy #1559

- Identity and changed requirements from sources 01–03.
  `soupsieve 3.0.4 → 4.0`.
- Use exact-head run and attempt/job evidence in sources 04–06 with exact-head
  workflow content in source 07. The CI path supports scoped successful
  requirements consumption observations. A reviewer may justify one named
  run/attempt/job/step example rather than enumerate every variant. Any
  enumeration must keep eight contexts and seven eligible observations distinct.
- The records do not show the actual package version installed or the importing
  test process. Relevant runs should not be inferred from sibling jobs alone.
- For a job with the declared `pip freeze`, seek its same-job output and
  interpret the version only for the pip environment observed. Same-process
  test use would require further continuity or import identity evidence.

## Dashboard API HTTPX #20

- Identity and change from sources 01–03.
  `httpx 0.27.2 → 0.28.1`.
- Source 04 returned zero exact-head runs at capture. Package release evidence
  (05–06) does exist. Sources 07–08 show two unavailable provenance responses
  for the proposed distribution files. A normal report therefore carries an
  unresolved publisher/source basis for release-interval interpretation.
- These observations leave target compatibility and API impact unresolved.
  A next check can seek an authoritative upstream source/release interval with
  exact provenance, or a target-relevant source or exact CI observation with a
  specific stated question. A reasoned lack of a justified next check is
  acceptable when tied to an unavailable material premise.
- Reject claims of global CI absence, a proven API change, safety or failure
  from the two 404s or an unverified repository link.
