# Your review assignment

Work through the case folders in this order.

1. [opencv](<01-opencv/START.md>)
2. [mapproxy](<02-mapproxy/START.md>)
3. [httpx](<03-httpx/START.md>)
