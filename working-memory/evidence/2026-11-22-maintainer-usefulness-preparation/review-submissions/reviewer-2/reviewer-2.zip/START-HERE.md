# Your review assignment

Work through the case folders in this order.

1. [httpx](<01-httpx/START.md>)
2. [mapproxy](<02-mapproxy/START.md>)
3. [opencv](<03-opencv/START.md>)
