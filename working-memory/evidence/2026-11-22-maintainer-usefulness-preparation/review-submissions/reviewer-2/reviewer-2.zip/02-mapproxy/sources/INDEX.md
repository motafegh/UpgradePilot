# Retained sources

Open the saved bodies from this index. URLs identify the original requests.

- 01. HTTP 200 · `https://api.github.com/repos/mapproxy/mapproxy/pulls/1559`
  [Exact retained JSON](01.json)
- 02. HTTP 200 · `https://api.github.com/repos/mapproxy/mapproxy/pulls/1559/files?per_page=100&page=1`
  [Exact retained JSON](02.json)
- 03. HTTP 200 · `https://api.github.com/repos/mapproxy/mapproxy/pulls/1559`
  [Exact retained JSON](03.json)
- 04. HTTP 200 · `https://api.github.com/repos/mapproxy/mapproxy/actions/runs?event=pull_request&head_sha=ac01b8901935bfc16a0195277b4aec1c43275897&per_page=100&page=1`
  [Exact retained JSON](04.json)
- 05. HTTP 200 · `https://api.github.com/repos/mapproxy/mapproxy/actions/runs/43457921398/attempts/1/jobs?per_page=100&page=1`
  [Exact retained JSON](05.json)
- 06. HTTP 200 · `https://api.github.com/repos/mapproxy/mapproxy/actions/runs/43457921398`
  [Exact retained JSON](06.json)
- 07. HTTP 200 · `https://api.github.com/repos/mapproxy/mapproxy/contents/.github/workflows/test.yml?ref=ac01b8901935bfc16a0195277b4aec1c43275897`
  [Exact retained JSON](07.json) · [Decoded source text](07.txt)
- 08. HTTP 200 · `https://pypi.org/pypi/soupsieve/4.0/json`
  [Exact retained JSON](08.json)
- 09. HTTP 200 · `https://pypi.org/pypi/soupsieve/3.0.4/json`
  [Exact retained JSON](09.json)
- 10. HTTP 200 · `https://pypi.org/integrity/soupsieve/4.0/soupsieve-4.0-py3-none-any.whl/provenance`
  [Exact retained JSON](10.json)
- 11. HTTP 200 · `https://pypi.org/integrity/soupsieve/4.0/soupsieve-4.0.tar.gz/provenance`
  [Exact retained JSON](11.json)
- 12. HTTP 200 · `https://pypi.org/pypi/soupsieve/json`
  [Exact retained JSON](12.json)
- 13. HTTP 200 · `https://api.github.com/repos/facelessuser/soupsieve/git/ref/tags/4.0`
  [Exact retained JSON](13.json)
- 14. HTTP 200 · `https://api.github.com/repos/facelessuser/soupsieve/git/commits/ff1a5ce7e5addc31626d7b6053511fecdb4f6320`
  [Exact retained JSON](14.json)
- 15. HTTP 200 · `https://api.github.com/repos/facelessuser/soupsieve/git/trees/475c56815c7fbc1dd5779a25652810e54767f904?recursive=1`
  [Exact retained JSON](15.json)
- 16. HTTP 200 · `https://api.github.com/repos/facelessuser/soupsieve/contents/docs/src/markdown/about/changelog.md?ref=ff1a5ce7e5addc31626d7b6053511fecdb4f6320`
  [Exact retained JSON](16.json) · [Decoded source text](16.txt)
